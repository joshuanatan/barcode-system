<div class="site-menubar">
  <div class="site-menubar-body">
    <div>
      <div>
        <ul class="site-menu" data-plugin="menu">
        <li class="site-menu-item">
            <a class="animsition-link" href="<?= base_url(""); ?>">
              <span class="site-menu-title">Home</span>
            </a>
          </li>
          <li class="site-menu-item">
            <a class="animsition-link" href="<?= base_url("product") ?>">
              <span class="site-menu-title">Product</span>
            </a>
          </li>
          <li class="site-menu-item">
            <a class="animsition-link" href="<?= base_url("user") ?>">
              <span class="site-menu-title">User</span>
            </a>
          </li>
          <li class="site-menu-item">
            <a class="animsition-link" href="<?= base_url("product/product_in") ?>">
              <span class="site-menu-title">Stock In</span>
            </a>
          </li>
          <li class="site-menu-item">
            <a class="animsition-link" href="<?= base_url("product/product_out") ?>">
              <span class="site-menu-title">Stock Out</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>

</div>