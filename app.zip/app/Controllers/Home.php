<?php

namespace App\Controllers;
use App\Libraries\RequestCheck;
use App\Models\OrderModel;
use App\Models\InquiryModel;

class Home extends BaseController
{
    protected $RequestCheck;

    public function __construct(){
        $this->RequestCheck = new RequestCheck();
    }

    public function index()
    {
        if(!$this->RequestCheck->isUser()){
            $sessionMsg = array(
                "status" => false,
                "msg" => "Session expired, please login"
            );
            session()->setFlashdata($sessionMsg);
            return redirect()->to(base_url()."login");
        }
        return view('dashboard/dashboard_content');
    }

    public function dashboard(){
        if (!$this->RequestCheck->isUser()) {
            $msgSession = array(
                "status" => false,
                "msg" => "You are not authorized"
            );
            echo json_encode($msgSession);
            return;
        }
        
        $inquiryModel = new InquiryModel();
        $orderModel = new OrderModel();


        $inquiry_weekly = $inquiryModel->list_amount_inquiry_weekly();
        $order_weekly = $orderModel->list_amount_order_weekly();
        $result = array(
            "widget" => array(
                array(
                    "value" => $inquiryModel->amount_inquiry_status("Open"),  
                    "title" => "Pending Inquiry"
                ),
                array(
                    "value" => $inquiryModel->amount_new_inquiry()[0]["amt"],
                    "title" => "New Inquiry"
                ),
                array(
                    "value" => $orderModel->amount_order_today("In Progress")[0]["amt"],
                    "title" => "On Going Order"
                )
            ),
            "bar_chart" => array(
                array(
                    "label" => $inquiry_weekly["date"],
                    "data" => $inquiry_weekly["amt"],
                    "label_name" => "Amount of Inquiries",
                ),
                array(
                    "label" => $order_weekly["date"],
                    "data" => $order_weekly["amt"],
                    "label_name" => "Amount of Orders",
                )
            )
        );
        echo json_encode($result);
        return;
    }
}
