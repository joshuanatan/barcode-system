<footer class="site-footer">
  <div class="site-footer-legal">© <?= date("Y") ?></div>
</footer>